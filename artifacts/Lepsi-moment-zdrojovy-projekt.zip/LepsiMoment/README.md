# Lepší moment

První nativní Android aplikace pro sestavení lepší skupinové fotografie z několika podobných snímků. Určeno především pro **Samsung Galaxy S24**; vyžaduje Android 10 nebo novější a procesor ARM64.

## Použití

1. Otevřete aplikaci a vyberte **2–6 fotek** stejné skupiny, ideálně ze série krátce po sobě.
2. Zvolte hlavní fotografii a klepněte na obličej, který chcete upravit.
3. Vyberte lepší výraz **stejného člověka** z jiného snímku. Nabídka používá polohu ve fotografii, nikoli rozpoznávání identity. Pokud se lidé přesunuli, otevřete „Vybrat z dalších obličejů“.
4. Přibližte náhled dvěma prsty. Pomocí „Před / Po“ zkontrolujte rozdíl; „Doladit“ nabízí posun, velikost, natočení, měkkost okraje a sladění barev. Můžete upravit více osob.
5. „Uložit novou fotku“ vytvoří JPG ve složce **Pictures/Lepsi moment**. Originály zůstanou beze změny.

Tlačítko „Původní“ vrací výraz vybrané osoby. „Zpět“ vrací poslední změnu. Rozpracovaná úprava se průběžně ukládá; po novém spuštění zvolte „Pokračovat v poslední úpravě“. Obnovení vyžaduje, aby původní fotky byly stále dostupné.

## Instalace na telefon

Hotové testovací APK je v `artifacts/Lepsi-moment-0.1.0.apk`. Přeneste soubor do telefonu a otevřete jej. Android může požádat o povolení instalace z aplikace, ve které APK otevíráte. Jde o lokálně podepsanou testovací sestavu, nikoli o aplikaci vydanou v Google Play.

## Co tato verze dělá

- Systémový výběr fotografií bez oprávnění číst celou galerii.
- Lokální detekce více obličejů pomocí přibaleného ML Kit Face Detection 16.1.7.
- Samostatná detekce obrysu každého obličeje ve výřezu. ML Kit při zapnutých konturách na celé skupinové fotografii poskytuje konturu jen dominantní tváře; proto se zpracovává každý výřez zvlášť.
- Zarovnání podle obou očí pomocí podobnostní transformace. Tvar úst a výraz ze zdrojového snímku zůstává zachovaný.
- Průnik masek obou tváří, bilineární převzorkování, vyrovnání barvy u okraje a plynulé prolínání. Když obrys není dostupný, použije se oválná maska.
- Obrázky se zpracovávají mimo hlavní vlákno, po jednom. V paměti zůstávají malé náhledy; samotné prolínání používá jen výřezy kolem tváře.
- Otočení a barevný prostor při načtení řeší Android ImageDecoder.
- Ukládání přes MediaStore do nové položky, včetně odstranění neúplného souboru při chybě.

## Soukromí a omezení

Aplikace nemá oprávnění `INTERNET`, nepoužívá server ani účet. Detekční model je součástí APK. Systémový výběr fotografií může nabídnout fotografie z uživatelova cloudového poskytovatele; samotná aplikace snímky neodesílá. Soukromý stav aplikace je vyloučen ze zálohování a přenosu dat.

Nejde o implementaci ani oficiální aplikaci Google Best Take. Jde o první funkční prototyp s geometrickým skládáním obličejů, nikoli generativní přestavbou hlavy. Nejlépe funguje při podobném osvětlení a natočení tváře. Silný profil, překážky před obličejem, výrazně jiné světlo, velmi malé tváře a velká změna úhlu mohou způsobit viditelné přechody. Příliš odlišné natočení aplikace odmítne. Návrhy podle polohy mohou obsahovat jiného člověka; správný zdroj volí uživatel.

Export je **JPG v sRGB / SDR**, kvalita 97, maximálně **4096 pixelů na delší straně**. Běžné 12MP snímky 4000 × 3000 px zůstanou v plném rozlišení. Větší snímky se zmenší. Nepřenáší se Ultra HDR, Motion Photo, RAW ani původní EXIF/GPS metadata. Aplikace není editor RAW.

## Sestavení

Potřebujete **JDK 17**, Android SDK 35 a Build Tools 35.0.0. Projekt používá Android Gradle Plugin 8.9.2 a Gradle 8.11.1, verze závislostí jsou pevně dané.

Otevřete adresář projektu v Android Studiu nebo nastavte `sdk.dir` v lokálním `local.properties` a spusťte:

```sh
./gradlew :app:assembleDebug :app:testDebugUnitTest :app:lintDebug
```

APK vznikne v `app/build/outputs/apk/debug/app-debug.apk`. Pro jiné procesorové architektury upravte `ndk.abiFilters` v `app/build.gradle`.

Integrační testy s připojeným ARM64 zařízením nebo emulátorem:

```sh
./gradlew :app:connectedDebugAndroidTest
```

Při prvním sestavení se stahuje Gradle a závislosti; běh aplikace je offline. Lokální `.tooling/` obsahuje vývojové nástroje a není součástí zdrojového balíčku. Release podepisování a publikace do obchodu nejsou nastaveny.

V tomto pracovním adresáři lze použít `sh scripts/build-local.sh`; využije již připravené nástroje a zachová stejný lokální testovací podpis. Soukromý podpisový klíč není součástí zdrojového ZIP. Při sestavení na jiném počítači vznikne jiný testovací klíč; Android pak místo aktualizace může vyžadovat odinstalování předchozí testovací verze (tím se odstraní její rozpracovaný stav, nikoli exportované fotky).

## Ověření

Automatické testy ověřují geometrii, zachování obrazu při identické náhradě, nedotčené okolí masky, měkký přechod, korekci barev, oříznutý zdroj a chybějící oči. Testy na Androidu zahrnují lokální detekci více tváří, kontury každé tváře, výměnu jen vybrané osoby, export, vrácení změny a obnovení Activity.

Testovací skupina je záměrně syntetická koláž veřejně dostupného portrétu NASA. Ověřuje funkčnost zpracování, nikoli přirozenost výměny různých výrazů v reálné sérii. Kvalitu na vašich fotografiích a provoz na skutečném Samsungu S24 je ještě potřeba ověřit. Konkrétní výsledky kontrol jsou v `VALIDATION.md`.

## Zdroje

- [ML Kit Face Detection pro Android](https://developers.google.com/ml-kit/vision/face-detection/android)
- [Možnosti a omezení detekce obličejů](https://developers.google.com/ml-kit/vision/face-detection/face-detection-concepts)
- [Android Photo Picker](https://developer.android.com/training/data-storage/shared/photo-picker)
- [Testovací portrét NASA / scikit-image](https://scikit-image.org/docs/stable/api/skimage.data.html#skimage.data.astronaut)

Zdrojový kód: `app/src/main/java/cz/honza/lepsimoment/`. Čisté matematické jádro je v podsložce `core/` a nemá závislost na Androidu.
